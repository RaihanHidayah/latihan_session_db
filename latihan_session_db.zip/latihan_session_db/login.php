<?php

session_start();
    
    if(isset($_SESSION['message'])){
        if($_SESSION['message']!=""){
            echo "<span 
            style= 'color: red'>".$_SESSION['message']."</span>";
            $_SESSION['message'] = "";
        }
    }

?>

<html>
<head>
    <title>Desain Form Login Dengan Css</title>
    <link rel="stylesheet" href="css.css">
</head>
<body>
    <div class="konten">
        <div class="kepala">
            <center>
            <h2 class="judul">Login</h2>
        </center>
        </div>
        <div class="artikel">
            <form action="ceklogin.php" method="post">
                <div class="grup">
                   
                    <input type="text" name="username"placeholder="Masukkan username">
                </div>
                <div class="grup">
                   
                    <input type="password" name="password"placeholder="Masukkan password ">
                </div>
                <div class="grup">
                    <input type="submit"name="Login" value="Login">
                    <center>
                       <p>Don't Have Account?</p>
                       <p><a href="register.php">Register Here!</p>
                    </center>
                </div>
            </form>
        </div>
    </div>
</body>
</html>