<?php
  //register.php
  session_start();

  if (isset($_SESSION['message'])) {
    if ($_SESSION['message']!="") {
      echo "<span style='color:red'>".$_SESSION['message']."</span>";
      $_SESSION['message'] = "";
    }
  }

 ?>
<html>
<head>
    <title>Desain Form Register Dengan Css</title>
    <link rel="stylesheet" href="registerstyle.css">
</head>
<body>
    <div class="konten">
        <div class="kepala">
            <center>
            <h2 class="judul">Register</h2>
        </center>
        </div>
        <div class="artikel">
            <form action="cekregister.php" method="post">
                <div class="grup">
                   
                    <input type="text" name="username"placeholder="Masukkan username">
                </div>
                <div class="grup">
                   
                    <input type="password" name="password"placeholder="Masukkan password ">
                </div>
                <div class="grup">
                    <input type="submit"name="register" value="Register">
                    <center>
                       <p>Already Have Account?</p>
                       <p><a href="login.php">Login Here!</p>
                    </center>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
